// main_designation_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:time_atten/Controller/Designation_Controller/designation_controller.dart';
import 'package:time_atten/View/Designation_Dialog/designation_dialog.dart';
// import 'designation_dialog.dart';
// import 'designation_controller.dart';

class MainDesignationScreen extends StatelessWidget {
  MainDesignationScreen({Key? key}) : super(key: key);

  final DesignationController controller = Get.find<DesignationController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Designation'),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add Designation'),
              onPressed: () => _showSmallDesignationDialog(context),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              ),
            ),
          )
        ],
      ),
      body: Container(
        width: double.infinity,
        color: Colors.grey[200],
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const SizedBox(height: 5),
              Expanded(
                child: Obx(() => ListView.builder(
                  itemCount: controller.masterDesignations.length,
                  itemBuilder: (context, index) {
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      child: ListTile(
                        title: Text(
                          controller.masterDesignations1[index],
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          'Master Designation: ${controller.masterDesignations[index]}',
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () => _showEditDialog(context, index),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => controller.deleteDesignation(index),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSmallDesignationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 100),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Container(
            width: 600,
            height: 300,
            child: DesignationDialog(controller: controller),
          ),
        );
      },
    );
  }

  void _showEditDialog(BuildContext context, int index) {
    // Prepare the dialog for editing
    controller.setDesignationName(controller.masterDesignations1[index]);
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 100),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Container(
            width: 600,
            height: 300,
            child: DesignationDialog(controller: controller),
          ),
        );
      },
    );
  }
}